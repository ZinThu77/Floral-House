<!DOCTYPE html>
<html>
<head>
	<title>Floral House</title>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>
	<h1 style="color: purple">Floral House</h1>
	<nav class="navbar navbar-expand-lg navbar-info bg-info">
		<div class="container-fluid">
			
			<ul class="nav navbar-nav">
				<li class="active"><a href="index.html">Home</a></li>
				<li><a href="#birthday">Birthday</a></li>
				<li><a href="#anniversary">Anniversary</a></li>
				<li><a href="#flowers">Flowers</a></li>
				<li><a href="#plants">Plants</a></li>
				<li><a href="#aboutus">About Us</a></li>
				<li><a href="#contactus">Contact Us</a></li>
			</ul>
		</div>
	</nav>
	<div id="birthday">
	<div class="container-fluid">
		<h1 style="color: purple">Birthday Bouquet</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Smile & Sunshine</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Light of My Life</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/b3.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Raspberry Rush</h4>
				<p style="text-align:center;">18000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="anniversary">
	<div class="container-fluid">
		<h1 style="color: purple">Anniversary Bouquet</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">You're Presious</h4>
				<p style="text-align:center;">25000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Classic Ivory</h4>
				<p style="text-align:center;">25000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/a3.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Ture Love</h4>
				<p style="text-align:center;">30000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="flowers">
	<div class="container-fluid">
		<h1 style="color: purple">Flowers</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f1.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">100 Roses</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f2.png" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Wild Flowers</h4>
				<p style="text-align:center;">20000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/f3.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Lavendar Bundles</h4>
				<p style="text-align:center;">35000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="plants">
	<div class="container-fluid">
		<h1 style="color: purple">Plants</h1>
		<div class="row">
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p1.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">20 Succulents</h4>
				<p style="text-align:center;">40000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p2.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Lucky Bamboo Plant</h4>
				<p style="text-align:center;">10000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
			<div class="col-sm-12 col-md-4">
				
				<div style="width: 300px; height: 300px">
					<img src="images/p3.jpg" class="img-responsive">
				</div>
				<h4 style="text-align:center;">Anthurium</h4>
				<p style="text-align:center;">10000 MMK</p>
				<button style="justify-content: center;" class="btn btn-primary;">Order</button>
			</div>
		</div>
	</div>
	<div id="aboutus">
        <div class="container-fluid">
        	<h1 style="color:purple;">About Us</h1>
        	<div class="row">
        		<div class="col-sm-6 col-md-3">
        			<h2>Owner</h2>
        			<p>Ms. Zin Thu</p>
        			<div style="width:200px; height: 200px">
        				<img src="images/owner.png" class="img-circle">
        			</div>
        		</div>
        		<div class="col-sm-6 col-md-3">
        			<h2>Florist</h2>
        			<p>Ms. Jenny</p>
        			<div style="width: 300px; height: 300px">
        				<img src="images/florist.png" class="img-circle">
        			</div>
        		</div>

	</div>
	<div id="contactus">
    <div class="container-fluid">
    	<h1 style="color: purple">Contact Us</h1>
    	<div class="row">
    		<div class="col-md-6 col-sm-12">
    			<h2>Shop Address</h2>
    			<p>Address: No.(155),<sup>nd</sup>Hnin Ni Street, Thuwana Township, Yangon, Myanmar</p>
    			<p>Phone: +95 9253462288, 9797609166</p>
    			<p>Email: floralhouse@gmail.com</p>
    		</div>
    		<div class="col-md-6 col-sm-12">
    			<img src="images/shop.jpg" class="img-responsive">
    		</div>
    	</div>
	</div>
</div>
<div class="col-md-6 col-sm-12">
	<h1>Floral House</h1>
	<h2>Location Map</h2>
		<div style="width: 100%"><iframe scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=600&amp;hl=en&amp;q=Hnin%20Si%20Ni%20Street,%20thuwana%20ward,%20yangon,%20myanmar+(Floral%20House)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="600" frameborder="0"></iframe><a href="https://www.mapsdirections.info/en/measure-map-radius/">Radius distance map</a></div>
	</div>
	<div class="col-md-6 col-sm-12">
		<h1>See Your location</h1>
		<button onclick="getLocation()">Check my location</button>
		<p id="demo"></p>
		<script>
var x = document.getElementById("demo");

function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else { 
    x.innerHTML = "Geolocation is not supported by this browser.";
    p=x.innerHTML;
  }
}

function showPosition(position) {
  x.innerHTML = "Latitude: " + position.coords.latitude + 
  "<br>Longitude: " + position.coords.longitude;
}
</script>
		</script>
		<div style="width: 100%"><iframe scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=100%25&amp;height=500&amp;hl=en&amp;q=p&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed" width="100%" height="600" frameborder="0"></iframe><a href="https://www.mapsdirections.info/en/measure-map-radius/">Radius distance map</a></div>
		
	</div>
	<div>
	
	<div>

	</div>
	</div>
	<!--Footer-->
	<div class="container-fluid">
	<div class="row">
	<hr>
	<footer>
		<p style="text-align: center;"><a href="#header">Home</a></p>
		<p style="text-align: center;"><a href="#header">Birthday</a></p>
		<p style="text-align: center;"><a href="#header">Anniversary</a></p>
		<p style="text-align: center;"><a href="#header">Flowers</a></p>
		<p style="text-align: center;"><a href="#header">Plants</a></p>
		<p style="text-align: center;"><a href="#header">About Us</a></p>
		<p style="text-align: center;"><a href="#header">Contact Us</a></p>
		<div style="text-align: center; font-size: 1.6em;">
		<a href="#" class="fa fa-facebook"></a>
		<a href="#" class="fa fa-instagram"></a>
		<a href="#" class="fa fa-twitter"></a>
		<a href="#" class="fa fa-envelope"></a>
		</div>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<h1><i class="fa fa-facebook"></i> | fa-facebook</h1>
		<p style="text-align: center;">&copy; Copyright 2021 floral_house.com</p>  
	</footer>
	<!--End of Footer-->
</div>
</div>
</div>
	
</body>
</html>
