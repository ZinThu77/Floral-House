<?php
class fmain extends CI_Controller
{
	public function index()
	{
		$this->load->view('fmain');
	}
	public function _construct()
	{
		parent::_Construct();
		$this->load->helper('url');
	}
}
